(function (exports) {
  const linked = require('./linked')
  Object.assign(exports, linked)
}((typeof module.exports !== 'undefined') ? module.exports : window))
