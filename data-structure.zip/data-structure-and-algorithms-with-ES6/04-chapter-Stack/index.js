(function (exports) {
  const {stack} = require('./stack.module')
  Object.assign(exports, {stack})
}((typeof module.exports !== undefined) ? module.exports : window))
