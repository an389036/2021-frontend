(function (exports) {
  const {tree} = require('./tree.module')
  Object.assign(exports, {tree})
}((typeof module.exports !== undefined) ? module.exports : window))
