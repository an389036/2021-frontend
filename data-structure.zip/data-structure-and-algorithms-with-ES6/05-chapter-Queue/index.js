(function (exports) {
  const {queue} = require('./queue.module')
  Object.assign(exports, {queue})
}((typeof module.exports !== undefined) ? module.exports : window))
