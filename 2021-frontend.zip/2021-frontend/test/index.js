employee = {
    name : "Ankita",
    title: "Ms"
}

persons = {
    employeeId : "1",
}
 persons = Object.assign(employee);
 persons = employee.bind(this);
 