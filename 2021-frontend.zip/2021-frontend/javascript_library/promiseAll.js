// Promise.all library function implementation.
function promiseAll(promises){
    let output = [];
    return new Promise((resolve, reject) => {
        promises.forEach((promise,i) => {
            promise.then(value =>{
                output[i] = value;
            })
        });
    })

}